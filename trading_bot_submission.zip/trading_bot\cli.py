import typer
from typing import Optional
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from bot.validators import validate_symbol, validate_side, validate_order_type, validate_quantity, validate_price
from bot.orders import place_futures_order

app = typer.Typer(help="Binance Futures Testnet Trading Bot CLI")
console = Console()

@app.command()
def order(
    symbol: str = typer.Argument(..., help="Trading symbol, e.g., BTCUSDT"),
    side: str = typer.Argument(..., help="BUY or SELL"),
    order_type: str = typer.Argument(..., help="Order type: MARKET or LIMIT"),
    quantity: float = typer.Argument(..., help="Quantity to trade"),
    price: Optional[float] = typer.Option(None, "--price", "-p", help="Price (required for LIMIT orders)")
):
    """
    Place a futures order on the Binance Testnet.
    """
    try:
        # Validate inputs
        symbol = validate_symbol(symbol)
        side = validate_side(side)
        order_type = validate_order_type(order_type)
        quantity = validate_quantity(quantity)
        if price is not None:
            price = validate_price(price)

        # Show summary table before placing order
        summary_table = Table(title="Order Request Summary", show_header=True, header_style="bold magenta")
        summary_table.add_column("Parameter", style="cyan")
        summary_table.add_column("Value", style="green")
        
        summary_table.add_row("Symbol", symbol)
        summary_table.add_row("Side", side)
        summary_table.add_row("Type", order_type)
        summary_table.add_row("Quantity", str(quantity))
        if price:
            summary_table.add_row("Price", str(price))

        console.print(summary_table)

        # Confirm with the user
        confirm = typer.confirm("Do you want to proceed with this order?")
        if not confirm:
            console.print("[yellow]Order cancelled.[/yellow]")
            raise typer.Abort()

        # Place the order
        with console.status("[bold green]Placing order...", spinner="dots"):
            response = place_futures_order(
                symbol=symbol,
                side=side,
                order_type=order_type,
                quantity=quantity,
                price=price
            )

        # Display result
        result_table = Table(title="Order Response", show_header=True, header_style="bold magenta")
        result_table.add_column("Field", style="cyan")
        result_table.add_column("Value", style="green")
        
        # Add key fields to the result table
        keys_to_show = ["orderId", "symbol", "status", "clientOrderId", "price", "origQty", "executedQty", "avgPrice", "type", "side"]
        for key in keys_to_show:
            if key in response:
                result_table.add_row(key, str(response[key]))

        console.print(result_table)
        console.print(Panel("[bold green]Order placed successfully![/bold green]"))

    except typer.Abort:
        pass
    except ValueError as e:
         console.print(f"[bold red]Validation Error:[/bold red] {e}")
         raise typer.Exit(code=1)
    except Exception as e:
        console.print(f"[bold red]Error placing order:[/bold red] {e}")
        console.print("Check trading_bot.log for detailed error logs.")
        raise typer.Exit(code=1)

if __name__ == "__main__":
    app()
