import argparse
import yaml
import pandas as pd
import numpy as np
import json
import logging
import time
import sys
import os

def setup_logger(log_file):
    logger = logging.getLogger("mlops_task")
    logger.setLevel(logging.INFO)
    
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    
    # File handler for run.log
    fh = logging.FileHandler(log_file)
    fh.setFormatter(formatter)
    logger.addHandler(fh)
    
    # Stream handler for stderr to not pollute stdout which expects JSON
    sh = logging.StreamHandler(sys.stderr)
    sh.setFormatter(formatter)
    logger.addHandler(sh)
    
    return logger

def write_metrics(output_file, version, status, metrics=None, error_message=None):
    if status == "success" and metrics:
        result = {
            "version": version,
            "rows_processed": metrics.get("rows_processed"),
            "metric": metrics.get("metric"),
            "value": metrics.get("value"),
            "latency_ms": metrics.get("latency_ms"),
            "seed": metrics.get("seed"),
            "status": status
        }
    elif status == "error" and error_message:
        result = {
            "version": version,
            "status": status,
            "error_message": error_message
        }
    else:
        result = {
            "version": version,
            "status": status
        }
        
    try:
        with open(output_file, 'w') as f:
            json.dump(result, f, indent=2)
    except Exception as e:
        print(f"Failed to write metrics to {output_file}: {e}", file=sys.stderr)
        
    # Requirements: Print final metrics JSON to stdout
    print(json.dumps(result, indent=2))
    
    return result

def main():
    start_time = time.time()
    
    parser = argparse.ArgumentParser(description="MLOps Batch Job")
    parser.add_argument("--input", required=True, help="Input CSV file")
    parser.add_argument("--config", required=True, help="Config YAML file")
    parser.add_argument("--output", required=True, help="Output metrics JSON file")
    parser.add_argument("--log-file", required=True, help="Log file path")
    
    args = parser.parse_args()
    
    version = "unknown"
    
    # Remove existing log file if it exists to keep it clean for the current run
    if os.path.exists(args.log_file):
        os.remove(args.log_file)
        
    logger = setup_logger(args.log_file)
    logger.info("Job started.")
    
    try:
        # 1. Load and validate config
        logger.info(f"Loading config from {args.config}")
        if not os.path.exists(args.config):
            raise FileNotFoundError(f"Config file {args.config} not found.")
            
        with open(args.config, 'r') as f:
            try:
                config = yaml.safe_load(f)
            except yaml.YAMLError as e:
                raise ValueError(f"Invalid YAML format: {e}")
            
        if not isinstance(config, dict):
            raise ValueError("Config file must be a valid YAML dictionary.")
            
        required_fields = ['seed', 'window', 'version']
        for field in required_fields:
            if field not in config:
                raise ValueError(f"Missing required config field: {field}")
                
        version = config['version']
        seed = config['seed']
        window = config['window']
        
        if not isinstance(window, int) or window <= 0:
            raise ValueError("Window must be a positive integer.")
            
        logger.info(f"Config validated. version={version}, seed={seed}, window={window}")
        
        # Set deterministic seed
        np.random.seed(seed)
        
        # 2. Load and validate dataset
        logger.info(f"Loading dataset from {args.input}")
        if not os.path.exists(args.input):
            raise FileNotFoundError(f"Input file {args.input} not found.")
            
        try:
            df = pd.read_csv(args.input)
        except Exception as e:
            raise ValueError(f"Invalid CSV format: {e}")
            
        if df.empty:
            raise ValueError("Input file is empty.")
            
        if 'close' not in df.columns:
            raise ValueError("Missing required column 'close' in dataset.")
            
        rows_processed = len(df)
        logger.info(f"Dataset loaded successfully. Rows: {rows_processed}")
        
        # 3. Rolling mean
        logger.info(f"Computing rolling mean with window {window}.")
        df['rolling_mean'] = df['close'].rolling(window=window).mean()
        
        # 4. Signal generation
        logger.info("Generating signals.")
        df['signal'] = np.where(df['close'] > df['rolling_mean'], 1, 0)
        
        # 5. Metrics & timing
        logger.info("Computing metrics.")
        signal_rate = float(df['signal'].mean())
        
        end_time = time.time()
        latency_ms = int((end_time - start_time) * 1000)
        
        metrics = {
            "rows_processed": rows_processed,
            "metric": "signal_rate",
            "value": round(signal_rate, 4),
            "latency_ms": latency_ms,
            "seed": seed
        }
        
        logger.info("Writing success metrics.")
        write_metrics(args.output, version, "success", metrics=metrics)
        logger.info(f"Job completed successfully in {latency_ms} ms.")
        sys.exit(0)
        
    except Exception as e:
        logger.error(f"Job failed: {str(e)}")
        write_metrics(args.output, version, "error", error_message=str(e))
        sys.exit(1)

if __name__ == "__main__":
    main()
