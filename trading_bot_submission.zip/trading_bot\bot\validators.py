import typer

def validate_symbol(symbol: str) -> str:
    if not symbol.isalnum():
        raise typer.BadParameter("Symbol must be alphanumeric (e.g., BTCUSDT).")
    return symbol.upper()

def validate_side(side: str) -> str:
    side = side.upper()
    if side not in ["BUY", "SELL"]:
        raise typer.BadParameter("Side must be either BUY or SELL.")
    return side

def validate_order_type(order_type: str) -> str:
    order_type = order_type.upper()
    valid_types = ["MARKET", "LIMIT", "STOP_MARKET", "TAKE_PROFIT_MARKET"]
    if order_type not in valid_types:
        raise typer.BadParameter(f"Order type must be one of {valid_types}.")
    return order_type

def validate_quantity(quantity: float) -> float:
    if quantity <= 0:
        raise typer.BadParameter("Quantity must be greater than 0.")
    return quantity

def validate_price(price: float) -> float:
    if price is not None and price <= 0:
        raise typer.BadParameter("Price must be greater than 0.")
    return price
