# MLOps Batch Job - Trading Signal Pipeline

A minimal, production-ready MLOps-style batch job that demonstrates reproducibility, observability, and deployment readiness.

## Project Structure

- `run.py`: The main batch job script.
- `config.yaml`: Configuration file (seed, window, version).
- `data.csv`: Input OHLCV dataset (10,000 rows).
- `requirements.txt`: Python dependencies.
- `Dockerfile`: Container definition to run the batch job in isolation.

## Running Locally

To run the batch job locally, ensure you have Python 3.9+ installed and follow these steps:

1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Execute the job:**
   ```bash
   python run.py --input data.csv --config config.yaml --output metrics.json --log-file run.log
   ```

3. **Check the outputs:**
   - The metrics will be output to standard out and saved to `metrics.json`.
   - Detailed logs are saved to `run.log`.

## Running with Docker (Recommended)

1. **Build the image:**
   ```bash
   docker build -t mlops-task .
   ```

2. **Run the container:**
   ```bash
   docker run --rm mlops-task
   ```

The final metrics JSON will be printed to stdout, which means it can be piped or captured cleanly. Inside the container, `metrics.json` and `run.log` are created. Note: The task evaluates successful zero exit code on success.

## Example Output (`metrics.json`)

```json
{
  "version": "v1",
  "rows_processed": 10000,
  "metric": "signal_rate",
  "value": 0.4990,
  "latency_ms": 127,
  "seed": 42,
  "status": "success"
}
```
