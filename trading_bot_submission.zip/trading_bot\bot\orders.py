from binance.exceptions import BinanceAPIException, BinanceRequestException
from typing import Optional, Dict, Any
from .logging_config import logger
from .client import get_binance_client

def place_futures_order(
    symbol: str, 
    side: str, 
    order_type: str, 
    quantity: float, 
    price: Optional[float] = None
) -> Dict[str, Any]:
    """
    Places a futures order on Binance Testnet.
    Returns the order response dict.
    Raises exceptions on failure.
    """
    client = get_binance_client()
    
    # Base parameters required for all orders
    params = {
        "symbol": symbol,
        "side": side,
        "type": order_type,
        "quantity": quantity
    }
    
    # Time in force is typically required for LIMIT orders
    if order_type == "LIMIT":
        if not price:
            raise ValueError("Price is required for LIMIT orders.")
        params["price"] = price
        params["timeInForce"] = "GTC" # Good Till Canceled
    elif order_type in ["STOP_MARKET", "TAKE_PROFIT_MARKET"]:
        if not price:
             raise ValueError(f"Stop Price is required for {order_type} orders.")
        params["stopPrice"] = price

    logger.info(f"Preparing to send order request: {params}")

    try:
        # Call the futures endpoint to create the order
        response = client.futures_create_order(**params)
        logger.info(f"Order successfully placed. Response: {response}")
        return response

    except BinanceAPIException as e:
        logger.error(f"Binance API Exception: Status: {e.status_code}, Message: {e.message}")
        raise e
    except BinanceRequestException as e:
        logger.error(f"Binance Request Exception: {e}")
        raise e
    except Exception as e:
        logger.error(f"Unexpected error occurred: {e}")
        raise e
