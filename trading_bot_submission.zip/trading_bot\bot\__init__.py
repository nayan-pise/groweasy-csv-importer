# Init bot package
