# Binance Futures Testnet Trading Bot

A simplified Python CLI application for placing orders on the Binance Futures Testnet (USDT-M). Built with `python-binance`, `typer`, and `rich` for an enhanced command-line experience.

## Features
- Place `MARKET` and `LIMIT` orders.
- Buy and Sell sides supported.
- Robust input validation and error handling.
- Rich CLI interface with an interactive summary and confirmation prompt.
- Detailed logging to `trading_bot.log`.

## Setup Steps

1. **Navigate to the Repository**
   Ensure you are in the project root directory (`trading_bot`).

2. **Create a Virtual Environment (Recommended)**
   ```bash
   python -m venv venv
   # On Windows:
   venv\Scripts\activate
   # On macOS/Linux:
   source venv/bin/activate
   ```

3. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Environment Variables**
   Set your Binance Futures Testnet API credentials as environment variables.
   
   **Windows (PowerShell):**
   ```powershell
   $env:BINANCE_API_KEY="your_testnet_api_key"
   $env:BINANCE_API_SECRET="your_testnet_api_secret"
   ```
   
   **Linux / macOS:**
   ```bash
   export BINANCE_API_KEY="your_testnet_api_key"
   export BINANCE_API_SECRET="your_testnet_api_secret"
   ```

## How to Run Examples

Use the `cli.py` script to place orders. You can see the full help menu with:
```bash
python cli.py --help
```

### 1. Market Order (BUY)
Place a market order for 0.01 BTC:
```bash
python cli.py BTCUSDT BUY MARKET 0.01
```

### 2. Limit Order (SELL)
Place a limit order to sell 0.01 BTC at 70000 USDT:
```bash
python cli.py BTCUSDT SELL LIMIT 0.01 --price 70000
```

### 3. Stop Market Order (Bonus)
Place a stop market order to buy 0.01 BTC when price reaches 65000:
```bash
python cli.py BTCUSDT BUY STOP_MARKET 0.01 --price 65000
```

## Logs

All API requests, responses, network errors, and exceptions are logged into the `trading_bot.log` file automatically. Check this file if you run into any issues.

## Assumptions
- You have a registered Binance Futures Testnet account and valid API credentials.
- The symbol requested exists and you have sufficient testnet USDT balance.
