import os
from binance.client import Client
from .logging_config import logger

def get_binance_client() -> Client:
    """
    Initializes and returns the Binance Client configured for the Futures Testnet.
    """
    api_key = os.getenv("BINANCE_API_KEY")
    api_secret = os.getenv("BINANCE_API_SECRET")

    if not api_key or not api_secret:
        logger.error("API keys not found in environment variables.")
        raise ValueError("Please set BINANCE_API_KEY and BINANCE_API_SECRET environment variables.")

    logger.info("Initializing Binance Client for testnet.")
    # Initialize the client. The testnet=True parameter configures it to use testnet URLs.
    client = Client(api_key, api_secret, testnet=True)
    return client
